class userInterface
{

    public fuelStation BP_FuelStation = new fuelStation();

    public int userChoice;
    bool scrnRefresh = true;
    ConsoleKeyInfo uki;
    bool validKeyPress2 = false;



    public void welcomeScreen()
    {
        Console.Clear();
        Console.WriteLine("\tWelcome to the Broken Petrol Ltd Fuel Attendant\n\tAssisstance Program\n\tPress Enter to continue, or Escape (Esc) to exit\n\t");
        bool validKeyPress = false;
        while(validKeyPress != true)
        {
            ConsoleKeyInfo uki = Console.ReadKey(true);
            switch(uki.Key)
            {
                case(ConsoleKey.Escape):
                {
                    validKeyPress = true;
                    userChoice = 1;
                    break;
                }
                case(ConsoleKey.Enter):
                {
                    validKeyPress = true;
                    userChoice = 2;
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    }

    public void homeScreen()
    {
        bool validKeyPress = false;
        Console.Clear();
        Console.WriteLine("\tWelcome Employee! Ready to earn that wage?");
        Console.WriteLine("\tPress the Escape (Esc) key to exit, or any\n\tof the indicated number keys to continue.");
        Console.WriteLine("\t1 - Start Shift\n\t2 - Shift Stats\n\t");
        while(validKeyPress != true)
        {
            ConsoleKeyInfo uki = Console.ReadKey(true);
            switch(uki.Key)
            {
                case(ConsoleKey.Escape):
                {
                    validKeyPress = true;
                    userChoice = 1;
                    break;
                }
                case((ConsoleKey.D1) or (ConsoleKey.NumPad1)):
                {
                    validKeyPress = true;
                    userChoice = 3;
                    break;
                }
                case((ConsoleKey.D2) or (ConsoleKey.NumPad2)):
                {
                    validKeyPress = true;
                    userChoice = 4;
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    }

    public void shiftScreen()
    {
        Console.Clear();
        Console.WriteLine("\tPress the number corresponding with an open pump to assign\n\ta vehicle to that pump.");
        Console.WriteLine("\tPress Escape (Esc) to end shift early, else press enter to begin the shift\n");
        Console.WriteLine("");
        bool exitToMenu = false;
        bool validKeyPress = false;
        int left, top;
        while(exitToMenu != true)
        {
            while(validKeyPress != true)
            {
                switch(uki.Key)
                {
                    case(ConsoleKey.Escape):
                    {
                        exitToMenu = true;
                        userChoice = 2;
                        validKeyPress = true;
                        break;
                    }
                    case(ConsoleKey.Enter):
                    {
                        validKeyPress = true;
                        break;
                    }
                    default:
                    {
                        break;
                    }
                }
            }
            if(exitToMenu == true)
            {
                break;
            }
            validKeyPress = false;
            Console.Clear();
            while(validKeyPress2 != true)
            {
                (left, top) = Console.GetCursorPosition();
                Console.WriteLine("\n\tQueue: {0}", "TBA");
                Console.WriteLine("\tPump 1: {0}\tPump 2: {1}\tPump 3: {2}\n\tPump 4: {3}\tPump 5: {4}\tPump 6: {5}\n\tPump 7: {6}\tPump 8: {7}\tPump 9: {8}\n", BP_FuelStation.pump[0], BP_FuelStation.pump[1], BP_FuelStation.pump[2], BP_FuelStation.pump[3], BP_FuelStation.pump[4], BP_FuelStation.pump[5], BP_FuelStation.pump[6], BP_FuelStation.pump[7], BP_FuelStation.pump[8]);
                Console.WriteLine("\tVehicles Serviced: {0}", "TBA");
                Console.SetCursorPosition(left, top);
                scrnRefresh = true;
                while(scrnRefresh != false)
                {
                    //
                    Thread.Sleep(40);
                    scrnRefresh = false;
                }
            }
        }
    }

    public void statsScreen()
    {

    }

    int vNum = 0;
    int xPos;
    int yPos;
    List<DateTime> fuelingStart = new List<DateTime>();
    int[] aaa = new int[9] {0,0,0,0,0,0,0,0,0};

    public void VehicleCounter()
    {
        while(userChoice != 1)
        {
            int pNum = 9;
            bool[,] localForecourtState = BP_FuelStation.getForecourtState();
            for(int n = 0; n < 3; n++)
            {
                for(int i = 0; i < 3; i++)
                {
                switch(n, i)
                {
                    case (0,0):
                    {
                        pNum = 0;
                        break;
                    }
                    case (0,1):
                    {
                        pNum = 1;
                        break;
                    }
                    case (0,2):
                    {
                        pNum = 2;
                        break;
                    }
                    case (1,0):
                    {
                        pNum = 3;
                        break;
                    }
                    case (1,1):
                    {
                        pNum = 4;
                        break;
                    }
                    case (1,2):
                    {
                        pNum = 5;
                        break;
                    }
                    case (2,0):
                    {
                        pNum = 6;
                        break;
                    }
                    case (2,1):
                    {
                        pNum = 7;
                        break;
                    }
                    case (2,2):
                    {
                        pNum = 8;
                        break;
                    }
                }
                    switch((localForecourtState[n,i]), (aaa[pNum]))
                    {
                        case(true, 0):
                        {
                            fuelingStart.Add(DateTime.Now);
                            xPos = n;
                            yPos = i;
                            vNum++;
                            aaa[pNum] = 1;
                            break;
                        }
                        default:
                        {
                            break;
                        }
                    }
                }
            }
        }
    }

    public void vehicleRemover()
    {
        int pNum = 11;
        while(userChoice != 1)
        {
            switch(xPos, yPos)
            {
                case (0,0):
                {
                    pNum = 1;
                    break;
                }
                case (0,1):
                {
                    pNum = 2;
                    break;
                }
                case (0,2):
                {
                    pNum = 3;
                    break;
                }
                case (1,0):
                {
                    pNum = 4;
                    break;
                }
                case (1,1):
                {
                    pNum = 5;
                    break;
                }
                case (1,2):
                {
                    pNum = 6;
                    break;
                }
                case (2,0):
                {
                    pNum = 7;
                    break;
                }
                case (2,1):
                {
                    pNum = 8;
                    break;
                }
                case (2,2):
                {
                    pNum = 9;
                    break;
                }
                default:
                {
                    break;
                }
            }
            if(fuelingStart != null)
            {
                int numloops = fuelingStart.Count();
                for(int i = 0; i < numloops; i++)
                {
                    DateTime entry = fuelingStart[i];
                    DateTime entry2 = entry.AddMilliseconds(8000);
                    switch(entry2.CompareTo(DateTime.Now))
                    {
                        case 0:
                        {
                            BP_FuelStation.pumpDeassigned(pNum);
                            BP_FuelStation.pump[pNum-1] = "OPEN";
                            fuelingStart.Remove(entry);
                            aaa[pNum-1] = 0;
                            break;
                        }
                        default:
                        {
                            break;
                        }
                    }
                    if(fuelingStart == null)
                    {
                        break;
                    }
                }
            }
        }
    }

    public void screenRefresher()
    {
        while(userChoice != 1)
        {
            uki = Console.ReadKey(true);
            switch(uki.Key)
            {
                case((ConsoleKey.D1) or (ConsoleKey.NumPad1)):
                {
                    BP_FuelStation.pumpAssigned(1);
                    break;
                }
                case((ConsoleKey.D2) or (ConsoleKey.NumPad2)):
                {
                    BP_FuelStation.pumpAssigned(2);
                    break;
                }
                case((ConsoleKey.D3) or (ConsoleKey.NumPad3)):
                {
                    BP_FuelStation.pumpAssigned(3);
                    break;
                }
                case((ConsoleKey.D4) or (ConsoleKey.NumPad4)):
                {
                    BP_FuelStation.pumpAssigned(4);
                    break;
                }
                case((ConsoleKey.D5) or (ConsoleKey.NumPad5)):
                {
                    BP_FuelStation.pumpAssigned(5);
                    break;
                }
                case((ConsoleKey.D6) or (ConsoleKey.NumPad6)):
                {
                    BP_FuelStation.pumpAssigned(6);
                    break;
                }
                case((ConsoleKey.D7) or (ConsoleKey.NumPad7)):
                {
                    BP_FuelStation.pumpAssigned(7);
                    break;
                }
                case((ConsoleKey.D8) or (ConsoleKey.NumPad8)):
                {
                    BP_FuelStation.pumpAssigned(8);
                    break;
                }
                case((ConsoleKey.D9) or (ConsoleKey.NumPad9)):
                {
                    BP_FuelStation.pumpAssigned(9);
                    break;
                }
                case (ConsoleKey.Escape):
                {
                    validKeyPress2 = true;
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    }

}