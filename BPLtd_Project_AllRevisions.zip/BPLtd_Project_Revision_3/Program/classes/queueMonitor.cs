//

// class Monitor
// {

//     public int localuserChoice;
//     public Monitor(){}
//     int vNum = 0;

//     List<int> VehicleList = new List<int>();

//     public void VehicleCounter()
//     {
//         while(localuserChoice != 1)
//         {
//             bool[,] localForecourtState = BP_FuelStation.getForecourtState();
//             for(int n = 0; n < 3; n++)
//             {
//                 for(int i = 0; i < 3; i++)
//                 {
//                     switch(localForecourtState[n,i])
//                     {
//                         case(true):
//                         {
//                             VehicleList.Add(vNum);
//                             vehgicleLifetime(DateTime.Now, vNum, n, i);
//                             vNum++;
//                             break;
//                         }
//                     }
//                 }
//             }
//         }
//     }

//     public void vehgicleLifetime(DateTime vgen, int cNum, int x, int y)
//     {
//         int xPos = x;
//         int yPos = y;
//         int pNum = 0;
//         switch(xPos, yPos)
//         {
//             case (0,0):
//             {
//                 pNum = 0;
//                 break;
//             }
//             case (0,1):
//             {
//                 pNum = 1;
//                 break;
//             }
//             case (0,2):
//             {
//                 pNum = 2;
//                 break;
//             }
//             case (1,0):
//             {
//                 pNum = 3;
//                 break;
//             }
//             case (1,1):
//             {
//                 pNum = 4;
//                 break;
//             }
//             case (1,2):
//             {
//                 pNum = 5;
//                 break;
//             }
//             case (2,0):
//             {
//                 pNum = 6;
//                 break;
//             }
//             case (2,1):
//             {
//                 pNum = 7;
//                 break;
//             }
//             case (2,2):
//             {
//                 pNum = 8;
//                 break;
//             }
//         }
//         int currentVNum = cNum;
//         DateTime start = vgen;
//         DateTime shdend = start.AddMilliseconds(8000);
//         bool passed = false;
//         while(passed != true)
//         {
//             switch(shdend.CompareTo(DateTime.Now))
//             {
//                 case 0:
//                 {
//                     passed = true;
//                     VehicleList.Remove(currentVNum);
//                     BP_FuelStation.pump[pNum] = "OPEN";
//                     break;
//                 }
//                 default:
//                 {
//                     break;
//                 }
//             }
//         }
//     }
// }