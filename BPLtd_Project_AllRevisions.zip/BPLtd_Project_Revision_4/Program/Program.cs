﻿// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 4.2, Revision 5
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// Program executable file.

// Initialisation
string thisProgramFilePath = Directory.GetCurrentDirectory();
userInterface thisInterface = new userInterface();
thisInterface.userChoice = 0;