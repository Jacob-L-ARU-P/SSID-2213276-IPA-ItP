// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 4.2, Revision 5
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// ForeCourt Class File.
class foreCourt
{
    // Forecourt attributes:
    // config integers inherited from the Fuel Station
    int lanesInForecourt;
    int pumpsPerLane;
    // Lanes represented by list, indexLane object allows,
    // procedurally generated Lane objects to be added.
    List<lane> lanesInTheForecourt = new List<lane>();
    lane indexLane = new lane();

    // Forecourt constructors:
    // Blank constructor for initial generation purposes
    // at program start.
    public foreCourt(){}
    // Constructor used once Fuel Station config has been read in.
    public foreCourt(int lIF, int pPL)
    {
        lanesInForecourt = lIF;
        pumpsPerLane = pPL;

        for(int i = 0; i < lanesInForecourt; i++)
        {
            indexLane = new lane(i, pPL);
            lanesInTheForecourt.Add(indexLane);
        }
    }

    // Forecourt method(s):

}