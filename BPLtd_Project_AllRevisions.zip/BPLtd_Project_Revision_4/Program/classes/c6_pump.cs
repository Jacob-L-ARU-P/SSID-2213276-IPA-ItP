// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 4.2, Revision 5
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// Pump Class File.
class pump
{
    // Pump attributes:
    // Lane and pump ID's provided by generating Lane
    int laneID;
    int pumpID;
    // Pump state, incredibly important.
    bool occupied;
    // Transactions, represented by a list, index transaction
    // used for adding new transactions to transaction list.
    List<transaction> localTransactionLog = new List<transaction>();
    transaction indexTransaction = new transaction();

    // Pump constructors:
    // Blank constructor for initial generation purposes
    // at program start.
    public pump(){}
    // Constructor used in Procedural Pump generation
    public pump(int pLID, int pID)
    {
        laneID = pLID;
        pumpID = pID;
        occupied = false;
    }

    // Pump method(s)

}