// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 4.2, Revision 5
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// Fuel Station Class file
class fuelStation
{
    // Fuel Station attributes:


    // Fuel Station constructors:
    // Blank constructor for initial generation purposes
    // at program start.
    public fuelStation(){}
    // Constructor used once Fuel Station config is confirmed to exist
    public fuelStation(string localFilePath)
    {

    }

    // Fuel Station methods:

}