// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 4.2, Revision 5
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// Transaction Class file.
class transaction
{
    // Transaction attributes:
    string? transactionID; // LaneID + PumpID + StartTime HH:MM:SS
    int laneID;
    int pumpID;
    // Transaction event Data
    DateTime startTime;
    DateTime endTime;
    TimeOnly ellapsedTime;
    // Fuel Data
    int fuelType;
    decimal fuelDispensed;
    int fuelCost;

    // Transaction constructors:
    // Blank constructor for initial generation purposes
    // at program start.
    public transaction(){}
    // Constructor used whenever a pump goes from "occupied = false"
    // to "occupied = true".
    public transaction(int lID, int pID, int fT)
    {
        startTime = DateTime.Now;
        laneID = lID;
        pumpID = pID;
        fuelType = fT;
    }
    
    // Transaction method(s):



}