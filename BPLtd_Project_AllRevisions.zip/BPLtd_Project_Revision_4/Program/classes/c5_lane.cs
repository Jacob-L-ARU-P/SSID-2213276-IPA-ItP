// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 4.2, Revision 5
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// Lane Class file.
class lane
{
    // Lane attributes:
    // Procedurally assigned Lane ID.
    int laneID;
    int pumpsPerLane;
    // Pumps represented by list, indexPump object allows,
    // procedurally generated Pump objects to be added.
    List<pump> pumpsIntheLane = new List<pump>();
    pump indexPump = new pump();

    // Lane constructors:
    // Blank constructor for initial generation purposes
    // at program start.
    public lane(){}
    // Constructor used in Procedural Lane generation
    public lane(int pIF, int pPL)
    {
        laneID = pIF;
        pumpsPerLane = pPL;
        for(int i = 0; i < pumpsPerLane; i++)
        {
            indexPump = new pump(laneID, i);
            pumpsIntheLane.Add(indexPump);
        }
    }

    // Lane method(s)


}