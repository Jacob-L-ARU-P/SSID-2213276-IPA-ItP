// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 4.2, Revision 5
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// User-Interface Class file.
class userInterface
{
    // User-Interface attributes:
    public int userChoice;

    // User-Interface methods:



}