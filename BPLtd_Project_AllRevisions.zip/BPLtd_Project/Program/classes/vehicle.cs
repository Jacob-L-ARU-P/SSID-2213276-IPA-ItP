// Vehicle Class
// Generic class, specific vehicle types inherit values from here

class vehicle
{
    // Randomly Generated Attributes
    int vehicleType;            // Vehicle Type (Influenced by Station Vehicle Restrictions)
    TimeSpan queueWaitTime;     // Random time between _ & _ whole seconds car will wait in queue before pre-emptively leaving
    float tankPercentLeft;      // Random number from 50 to 2, represents percentage of tank left on arrival at fuel station
    bool desiredTransaction;    // Decides wether "driver" wants to fill up based on 'price' or 'litres of fuel'

    // Dependant Attributes
    int maxFuel;                // Dependant on vehicle type:
    int fuelRestrictions;       // Dependant on vehicle type:

    // Dependant on Transaction Type:
    decimal coinWillingPay;     // Random number (min sale 5 litres), represents amount of money driver is willing to spend on fuel
    double tankPercentDesired;  // Random number from 60 to 100, represents how much fuel should be in tank when car leaves


    // Constructor, called by _
    public vehicle()
    {

    }

    // Methods


}