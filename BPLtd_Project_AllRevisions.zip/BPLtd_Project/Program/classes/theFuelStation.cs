// The Fuel Station Class
class FuelStation
{

// ------------------------------------------------------------------------------------------------------------------------
// Station Attributes
string[] FSConfigInOut;
List<string> FSCIOValues = new List<string> ();
string FuelStationName;
int FuelStationID;
int PumpsPerLane;
int LanesInForecourt;
int FuelsOffered;
int VehicleRestrictions;
int QueueSize;
// ------------------------------------------------------------------------------------------------------------------------
// Station Objects
// ------------------------------------------------------------------------------------------------------------------------
// Account Objects primarily differentiate account type and permissions
public bpl_userAccount accountsAdmin = new bpl_userAccount();
public bpl_userAccount accountsEManager = new bpl_userAccount();
public bpl_userAccount accountsEmployee = new bpl_userAccount();
// ------------------------------------------------------------------------------------------------------------------------
// List of fuel objects, as while they follow a naming convention
// there could be any number of fuel config files in the folder
// current artificial max of 10 due to program scope.
public List<fuel> stationFuels = new List<fuel>();
// ------------------------------------------------------------------------------------------------------------------------
// Lane(s) objects
public List<lane> stationLanes = new List<lane>();
// ------------------------------------------------------------------------------------------------------------------------
// Queue-Monitor: Controls vehicle generation & logging total cars that visited vs those that left early

// ------------------------------------------------------------------------------------------------------------------------
// Pump-Manager: Intermediate object, controls shift-mode (Manual or Auto), vehicle pump assignment

// ------------------------------------------------------------------------------------------------------------------------
// Fuel Station Constructor(s) (Called at program start, after checking for valid config file)
public FuelStation(){}
public FuelStation(string filepath)
{
    // Read In Config File
    FSConfigInOut = File.ReadAllLines(filepath);
    string[] linesplit;
    int i = 0;
    // Trim readability whitespace from config file
    // And Get Config Values
    foreach(string line in FSConfigInOut)
    {
        FSConfigInOut[i] = line.Trim();
        linesplit = line.Split(":");
        FSCIOValues.Add(linesplit[1]);
        i++;
    }        
    // Assign Config Values to Station Attributes
    for(int n = 0; n < i; n++)
    {
        switch(n)
        {
            case 0:
            {
                this.FuelStationName = FSCIOValues[n];
                break;
            }
            case 1:
            {
                this.FuelStationID = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 2:
            {
                // Nothing to Assign Here
                break;
            }
            case 3:
            {
                this.PumpsPerLane = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 4:
            {
                this.LanesInForecourt = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 5:
            {
                this.FuelsOffered = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 6:
            {
                this.VehicleRestrictions = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 7:
            {
                this.QueueSize = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
        }
    }
}
// ------------------------------------------------------------------------------------------------------------------------
// get Station Data Method(s)


// ------------------------------------------------------------------------------------------------------------------------
// set Station Data Method(s) ----- Admin Only


// ------------------------------------------------------------------------------------------------------------------------
// set Station Data Method(s) ----- Manager Only


// ------------------------------------------------------------------------------------------------------------------------
// generatecomponents station components
public void generatecomponents(string MyexpectedConfigsFolderpath)
{
    // Fuel Station Build Order:
    // -------------------------
    // Generate User Account Objects
    // Constructor input(folder/filepath, flag)
    // Is there an Admin config?   
    try
    {
        string[] checklines = File.ReadAllLines(MyexpectedConfigsFolderpath + "\\accounts\\accAdmin.txt");
        int i = 0;
        foreach(string line in checklines)
        {
            i++;
        }
        int iC = i % 4;
        if(iC != 0)
        {
            throw new Exception("Bad Config");
        }
        else
        {
            accountsAdmin = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts\\accAdmin.txt", 0, false);
        }
    }
    catch(FileNotFoundException)
    {
        accountsAdmin = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts", 1, false);
    }
    catch(Exception)
    {
        accountsAdmin = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts\\accAdmin.txt", 0, true);        
    }
    // Is there an EManager config?
    try
    {
        string[] checklines = File.ReadAllLines(MyexpectedConfigsFolderpath + "\\accounts\\accEManager.txt");
        int i = 0;
        foreach(string line in checklines)
        {
            i++;
        }
        int iC = i % 4;
        if(iC != 0)
        {
            throw new Exception("Bad Config");
        }
        else
        {
            accountsEManager = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts\\accEManager.txt", 2, false);
        }
    }
    catch(FileNotFoundException)
    {
        accountsEManager = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts", 3, false);
    }
    catch(Exception)
    {
        accountsAdmin = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts\\accEManager.txt", 2, true);
    }
    // Is there an Employee config?
    try
    {
        string[] checklines = File.ReadAllLines(MyexpectedConfigsFolderpath + "\\accounts\\accEmployee.txt");
        int i = 0;
        foreach(string line in checklines)
        {
            i++;
        }
        int iC = i % 4;
        if(iC != 0)
        {
            throw new Exception("Bad Config");
        }
        else
        {        
            accountsEmployee = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts\\accEmployee.txt", 4, false);
        }
    }
    catch(FileNotFoundException)
    {
        accountsEmployee = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts", 5, false);
    }
    catch(Exception)
    {
        accountsEmployee = new bpl_userAccount(MyexpectedConfigsFolderpath + "\\accounts\\accEmployee.txt", 4, true);
    }

    // Fuel Objects
    // FuelsOffered: 0 = Pass Flag to UserInterface, don't gen any blanks
    //               1 = Check for existing Petrol config
    //               2 = unused
    //               3 = Check for existing Petrol, Disel & LPG
    //               4 through 10 = Check for main 3, plus any extra existing configs
    // Check fuels config for any existing, gen blank txt docs if lacking
    // Set flag for Manager/Admin accounts that they need to add fuel type data to any blanks
    // "S:\\University Projects\\Intro to Programming\\BPLtd_Project\\Program\\configs\\fuels"
    // "K:\\BPLtd_Project\\Program\\configs\\fuels"
    switch(FuelsOffered)
    {
        case 0:     // Station is Closed for business
        {
            break;
        }
        case 1:     // try to read fuelUnleadedPetrol.txt in fuels folder
        {
            break;
        }
        case 2:     // Currently unused
        {
            break;
        }
        case 3:     // try to read fuelUP.txt, fuelD.txt, fuelLPG.txt in fuel folder
        {
            break;
        }
        case (>=4) and (<=10):  // try to read *any* fuel'Type'.txt in fuel folder
        {
            break;
        }
    }

    // Que Monitor
    // Instantiate the Vehicle Generator and set parameters as per restrictions
    // Generate the Forecourt's Queue list, for new vehicles to be added to


    // Forecourt Lane(s)


    // Forecourt Lane(s) Pump(s)


    // 

}
}