// Pump Class
// Component of a Forecourt Lane, minimum of 1
// Generates a Transaction object when occupied
// --------------------------------------------
class pump
{
// Pump class attributes
int laneID;
int pumpID;
bool Occupied;
List<transaction> pumpTransactions = new List<transaction>();

// Constructor
    public pump(){}
    public pump(int objectiser)
    {

    }

// get method(s)


// set method(s)


// Generate Transaction


}