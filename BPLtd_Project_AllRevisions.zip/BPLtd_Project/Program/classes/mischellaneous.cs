// User Interface Method(s)
//
class UserInterface
{
// Uni expected file path: "K:\\BPLtd_Project\\Program\\configs\\station\\config.txt"
// Home expected file path: "S:\\University Projects\\Intro to Programming\\BPLtd_Project\\Program\\configs\\station\\config.txt"
public string MyexpectedConfigsFolderpath;
// 
public int userChoice;
public int accountsPresent;
public FuelStation BP_FuelStation = new FuelStation();

// Methods

// Generates Console Window with some text, in the event
// that the worker thread generating the Fuel Station
// chugs for some reason
public void startscreen()
{
    Console.Clear();
    Console.Write("\n\n\n\t...Loading Please Wait...\n");
}

// Welcome Splash Screen
// Confirms program initialised, ask you to press enter to continue or esc to exit, accepts no other inputs
public void welcomescreen()
{
    // local logic bool(s)
    bool validKeyPress = false;
    // Make user press enter key to go to login
    while(validKeyPress != true)
    {
    Console.Clear();
    Console.WriteLine("\tWelcome to the Broken Petrol Ltd");
    Console.WriteLine("\tFuel Station Managemant Aid Program");
    Console.WriteLine("\n\tPress Enter to Continue to login");
    Console.WriteLine("\n\tOr Escape (esc) to exit.");
    switch(Console.ReadKey(true).Key)
    {
        case ConsoleKey.Escape:
        {
            userChoice = 1;
            validKeyPress = true;
            break;
        }
        case ConsoleKey.Enter:
        {
            userChoice = 11;
            validKeyPress = true;
            break;
        }
        default:
        {
            break;
        }
    }
    }
}

// "Public" User Login Select Screen
public void userLoginSelectscreen()
{
    // Local Logic variable(s)
    bool validKeyPress = false;
    int subinterface;
    ConsoleKeyInfo ski;
    // "Public" login screen, needs to check if there are valid EManager and Employee configs
    switch(BP_FuelStation.accountsEManager.ConfigStatus.Contains("NOTICE:"), BP_FuelStation.accountsEmployee.ConfigStatus.Contains("NOTICE:"))
    {
        case (true, true): // Both present and accounted for. No Problems
        {
            subinterface = 0;
            break;
        }
        case(true, false): // Manager account(s) work, Employee account(s) some level of scuffed. Not necessarily a Problem
        {
            subinterface = 1;
            break;
        }
        case(false, true): // Manager account(s) some level of scuffed, Employee account(s) still work. Probably a Problem
        {
            subinterface = 2;
            break;
        }
        case(false, false): // Both account types some level of scuffed. Definitely a Problem
        {
            subinterface = 3;
            break;
        }
    }
    // Display contextual user-login screen
    Console.Clear();
    switch(subinterface)
    {
        case 0:
        {
            Console.WriteLine("\t--- Broken Petrol Ltd ----- Fancy Login-Screen Pending ---");
            Console.WriteLine("\tNOTICE: No issues detected on program load.\n\tTo select a menu option, please press the indicated key.");
            Console.WriteLine("\t1 - Employee Login\n\t2 - Manager Login\n\tEsc - Exit Program");
            break;
        }
        case 1:
        {
            Console.WriteLine("\t--- Broken Petrol Ltd ----- Fancy Login-Screen Pending ---");
            Console.WriteLine("\tWARNING: Issues detected on program load.\n\tPlease inform a site Manager or Admin.");
            Console.WriteLine("\tTo select a menu option, please press the indicated key.");
            Console.WriteLine("\t{0}\n\t2 - Manager Login\n\tEsc - Exit Program", BP_FuelStation.accountsEmployee.ConfigStatus);            
            break;
        }
        case 2:
        {
            Console.WriteLine("\t--- Broken Petrol Ltd ----- Fancy Login-Screen Pending ---");
            Console.WriteLine("\tWARNING: Issues detected on program load.\n\tPlease inform a site Manager or Admin.");
            Console.WriteLine("\tTo select a menu option, please press the indicated key.");
            Console.WriteLine("\t1 - Employee Login\n\t{0}\n\tEsc - Exit Program", BP_FuelStation.accountsEManager.ConfigStatus);            
            break;
        }
        case 3:
        {
            Console.WriteLine("\t--- Broken Petrol Ltd ----- Fancy Login-Screen Pending ---");
            Console.WriteLine("\tWARNING: CRITICAL ERRORS DETECTED ON LOAD!\n\tPlease inform a site Admin.");
            Console.WriteLine("\tTo select a menu option, please press the indicated key.");
            Console.WriteLine("\t1 - {0}\n\t2 - {1}\n\tEsc - Exit Program");
            break;
        }
    }
    // User-input while loop
    while(validKeyPress != true)
    {
        ski = Console.ReadKey(true);
        switch(ski.Key, (ski.Modifiers == ConsoleModifiers.Shift), (ski.Modifiers == ConsoleModifiers.Alt), (ski.Modifiers == ConsoleModifiers.Control), subinterface)
        {
            case (ConsoleKey.Escape, false, false, false, >=0): // Exit Program, doesn't care about current context
            {
                userChoice = 1;
                validKeyPress = true;
                break;
            }
            case (ConsoleKey.D1 or ConsoleKey.NumPad1, false, false, false, not 1 or 3):
            {
                userChoice = 2;
                validKeyPress = true;
                break;
            }
            case (ConsoleKey.D2 or ConsoleKey.NumPad2, false, false, false, not 2 or 3):
            {
                userChoice = 3;
                validKeyPress = true;
                break;
            }
            case (ConsoleKey.D5 or ConsoleKey.NumPad5, true, false, false, >=0): // Needs to be made to only work for 'Shift + 5'
            {
                userChoice = 5;
                validKeyPress = true;
                break;
            }
            default:
            {
                break;
            }
        }
    }
}

// General Login Screen
public void userLoginScreen()
{
    // local logic variables
    bool validKeyPress = false;
    string uNtC, uPtC; // strings to be checked against Manager/Employee accounts
    Console.TreatControlCAsInput = true; // Control+C typically being "Control Close" shortcut I think?
    ConsoleKeyInfo uki;

    // login screen
    Console.Clear();
    Console.WriteLine("\t----- Broken Petrol Ltd: Fuel Attendant Login -----");
    Console.WriteLine("\t-----  Please enter your Username & Password  -----");
    Console.WriteLine("\t-----  Press Enter to submit login field, or  -----");
    Console.WriteLine("\t-----    Escape (Esc) to go back to login.    -----");
    while(validKeyPress != true)
        {
            try
            {
            Console.Write("\t--- Username: ");
            uNtC = Console.ReadLine();
            Console.Write("\n\t--- Password: ");
            uPtC = Console.ReadLine();
            }
            catch(IOException)
            {

            }
            catch(OutOfMemoryException)
            {

            }
            catch(ArgumentOutOfRangeException)
            {
                
            }
        }
}

// "Hidden" admin login screen
public void adminLoginScreen()
{
    // Local Logic Variable(s)
    bool validKeyPress = false;
    // Admin login screen

    // User-input while loop
    while(validKeyPress != true)
    {
        
    }
}

// Admin Screen
public void userAdminscreen()
{

}

// Employee Manager Screen
public void userEManagerscreen()
{

}

// Employee Screen
public void userEmployeescreen()
{

}

// Get Current Filepath ----- Gets current filepath for program
public void appendFilepath()
{
    
} 


// Sanity Check ----- Checks/Validates/Tests Fuel Station Config File before generating the Program's Fuel Station Object
public void sanitycheck()
{
    // check file exists
    try
    {
    File.ReadAllLines(MyexpectedConfigsFolderpath + "\\station\\config.txt");
    Console.Write("\t...05%...\n");
    // Read in all lines of config
    string[] lines = File.ReadAllLines(MyexpectedConfigsFolderpath + "\\station\\config.txt");
    // intermediate array for splitting up each line
    string[] lineSplit;
    // Final array of split config data, col 0 = config name, col 1 = config value
    string[,] splitLineStack = new string[lines.Length,2];
    // indexing counter
    int i = 0;
    // Trim readability whitespace from config file
    foreach(string line in lines)
    {
        lines[i] = line.Trim();
        i++;
    }    
    Console.Write("\t...10%...\n");
    // Split each line of config file and save to new array
    i = 0;
    foreach(string line in lines)
    {
        lineSplit = line.Split(":");
        splitLineStack[i,0] = lineSplit[0];
        splitLineStack[i,1] = lineSplit[1];
        i++;
    }
    Console.Write("\t...15%...\n");
    // Check config file is "good"
    for(int n = 0; n < i; n++)
    {
    // Check all expected config fields are present
        switch(splitLineStack[n,0])
        {
            case("FuelStationName"):
            {
                break;
            }
            case("FuelStationID"):
            {
                break;
            }
            case("StationData"):
            {
                break;
            }
            case("PumpsPerLane"):
            {
                break;
            }
            case("LanesInForecourt"):
            {
                break;
            }
            case("FuelsOffered"):
            {
                break;
            }
            case("VehicleRestrictions"):
            {
                break;
            }
            case("QueueSize"):
            {
                break;
            }
        // In the event a line from the config does NOT match any
        // of the expected fields, throw an error
            default:
            {
                throw new Exception("Missing Expected Config Field");
            }
        }
    // Check all expected fields have an appropriate non-null value
    // I.e. Station name is a string with any amount of characters in it,
    // Station ID and such are positive integers, etc. Otherwise, throw error
        switch(splitLineStack[n,1])
        {
            case(null):
            {
                 throw new Exception("Missing Valid Config Field Value");
            }
            default:
            {
                switch(n)
                {
                    case 0:
                        // Check Station Name is not empty string
                    {
                        string a = splitLineStack[0,1];
                        bool b = string.IsNullOrEmpty(a);
                        bool c = string.IsNullOrWhiteSpace(a);
                        if(b == true)
                        {
                            throw new Exception("Missing Valid Station Name");
                        }
                        else if(c == true)
                        {
                            throw new Exception("Missing Valid Station Name,\n\tcannot be whitespace, e.g. '    '.");
                        }
                        else
                        {
                            break;
                        }
                    }
                    case 1:
                        // Check Station has a valid, non-zero, non-negative ID number
                    {
                        int a = Convert.ToInt32(splitLineStack[1,1]);
                        if(a > 0)
                        {
                            break;
                        }
                        else
                        {
                            throw new Exception("Missing Valid Config Field Value");
                        }
                    }
                    case 2:
                        // Check's StationData line hasn't been messed with
                    {
                        if(splitLineStack[2,1] == "#")
                        {
                            break;
                        }
                        else
                        {
                            throw new Exception("Missing StationData Config Field Value, should be '#'.");
                        }
                    }
                    case 3:
                        // Checks Pumps Per Lane is a non-zero, non-negative, less than 10 integer
                    {
                        int a = Convert.ToInt32(splitLineStack[3,1]);
                        switch(a)
                        {
                            case <=0:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                            }
                            case >10:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tshould be 10 or less");
                            }
                            default:
                            {
                                break;
                            }
                        }
                        break;
                    }
                    case 4:
                        // Checks Lanes in Forecourt is a non-zero, non-negative, less than 10 integer
                    {
                        int a = Convert.ToInt32(splitLineStack[4,1]);
                        switch(a)
                        {
                            case <=0:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                            }
                            case >10:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tshould be 10 or less");
                            }
                            default:
                            {
                                break;
                            }
                        }
                        break;
                    }
                    case 5:
                        // Checks Fuels Offered is a non-negative, less than 10 integer
                    {
                        int a = Convert.ToInt32(splitLineStack[5,1]);
                        switch(a)
                        {
                            case <0:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                            }
                            case >10:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tshould be 10 or less.\n\tMore than 11 types of fuel is outside the scope of this project");
                            }
                            default:
                            {
                                break;
                            }
                        }
                        break;
                    }
                    case 6:
                        // Checks Vehicle Restrictions is a non-negative, less than 5 integer
                    {
                        int a = Convert.ToInt32(splitLineStack[6,1]);
                        switch(a)
                        {
                            case <=0:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                            }
                            case >5:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tshould be 5 or less.\n\tHigher Values outside project scope.");
                            }
                            default:
                            {
                                break;
                            }
                        }
                        break;
                    }
                    case 7:
                        // Checks Forecourt Queue is a non-zero, non-negative, less than 10 integer
                    {
                        int a = Convert.ToInt32(splitLineStack[3,1]);
                        switch(a)
                        {
                            case <=0:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                            }
                            case >10:
                            {
                                throw new Exception("Missing Valid Config Field Value,\n\tshould be 10 or less");
                            }
                            default:
                            {
                                break;
                            }
                        }
                        break;
                    }
                    default:
                        // In the Event More FuelStation Config lines are added, without an associated valid value check
                    {
                        throw new Exception("Missing Expected Config Field Value Check");
                    }
                }
                break;
            }
        }
    }
    Console.Write("\t...25%...\n");
    // Config Exists and is not "Corrupt"
    // Doesn't mean any of the values won't break the program later though
    // Pass config filepath to constructor
    // Thus Creating the programs Fuel Station Object, local instance called 'BP_FuelStation'
    BP_FuelStation = new FuelStation(MyexpectedConfigsFolderpath + "\\station\\config.txt");
    Console.Write("\t...30%...\n");
    BP_FuelStation.generatecomponents(MyexpectedConfigsFolderpath);
    Console.Write("\t90%...\n\n");
    }
    // Error Catching
    catch(FileNotFoundException)
    {
        Console.Clear();
        Console.WriteLine("\n\tWARNING: Fuel Station Config Not Found!");
        Thread.Sleep(250);
        userChoice = 1;
    }
    catch(System.IO.IOException e)
    {
        Console.Clear();
        Console.WriteLine("\n\tWARNING: Unexpected Error!");
        Console.WriteLine("\t" + e.Message);
        Thread.Sleep(250);
        userChoice = 1;
    }
    catch(FormatException)
    {        
        Console.Clear();
        Console.WriteLine("\n\tWARNING: Bad Config/Config Corrupt!");
        Console.WriteLine("\tAttempted to Convert letter(s) to numbers,\nfailed.");
        Thread.Sleep(250);
        userChoice = 1;
    }
    catch(OverflowException)
    {
        Console.Clear();
        Console.WriteLine("\n\tWARNING: Bad Config/Config Corrupt!");
        Console.WriteLine("\tValue in Config too large, expected 32-bit integer.");
        Thread.Sleep(250);
        userChoice = 1;       
    }
    // Custom Exception Catch
    catch(Exception e)
    {
        Console.Clear();
        Console.WriteLine("\n\tWARNING: Bad Config/Config Corrupt!");
        Console.WriteLine("\t" + e.Message);
        Thread.Sleep(250);
        userChoice = 1;
    }
}
}