// Generic User Profile Class
// The Admin Account(s) is a complete instance of this class
// The Manager and Employee Account(s) are limited scope instances of this class

class bpl_userAccount
{
    // Class Attributes
    List<int> usaccType = new List<int> ();
    List<int> usaccID = new List<int> ();
    List<string> usaccName = new List<string> ();
    List<string> usaccPass = new List<string> ();
    public string ConfigStatus;

    // Constructor(s)
    public bpl_userAccount(){}
    public bpl_userAccount(string folderfilepath, int genDesc, bool badConfig)
    {
        // folderfilepath: "Drive:\\...\\BPLtd_Project\\Program\\configs\\accounts\\accTypeConfig.txt" OR "Drive:\\...\\BPLtd_Project\\Program\\configs\\accounts"
        // genDesc: 0 = Admin Account(s) present, append default; 1 = No Admin Account(s), gen default Admin
        //          2 = Manager Account(s) present; 3 = No Manager Account(s)
        //          4 = Employee Account(s) present; 5 = No Employee Account(s)
        // badConfig, expected value is false
        // --------------------------------------------------------------------------------------
        bool localSanityCheck = false;
        while(localSanityCheck != true)
        {
            if(badConfig == true)
            {
                switch(genDesc)
                {
                    case 0:     // Bad Admin Config
                    {
                        // Make default admin for object
                        usaccType.Add(0);
                        usaccID.Add(0);
                        usaccName.Add("DefaultAdmin");
                        usaccPass.Add("D0000A");
                        // Set bad admin config flag
                        ConfigStatus = "WARNING: Local Admin Config file Corrupted!";

                        // Sanity check true
                        localSanityCheck = true;
                        break;
                    }
                    case 2:     // Bad Employee Manager Config
                    {
                        // Set bad Manager flag
                        ConfigStatus = "ERROR: Local Manager Config file Corrupted!";

                        // Sanity check true
                        localSanityCheck = true;
                        break;
                    }
                    case 4:     // Bad Employee Config
                    {
                        // Set bad Employee flag
                        ConfigStatus = "ERROR: Local EMployee Config file Corrupted!";

                        // Sanity check true
                        localSanityCheck = true;
                        break;
                    }
                }
            }
            else // badConfig == false
            {
                try
                {
                    switch(genDesc)
                    {
                        case 0:     // Admin Account(s) Present
                        {
                            // Read in from accAdmin file
                            string[] linesa = File.ReadAllLines(folderfilepath);
                            string[] linesplita;
                            int a = 0;
                            // Get values from admin config, overwrite stored line with said value, counter +1
                            foreach(string line in linesa)
                            {
                                linesplita = line.Split(":");
                                linesa[a] = linesplita[1];
                                a++;
                            }                          
                            // Apply config values to object attributes, 'i' should always be a multiple of 4 if good config
                            for(int n = 1; n < a; n = n + 4)
                            {
                                usaccType.Add(Convert.ToInt32(linesa[n-1]));
                                usaccID.Add(Convert.ToInt32(linesa[n]));
                                usaccName.Add(linesa[n+1]);
                                usaccPass.Add(linesa[n+2]);
                            }
                            // Add default Admin values to object
                            usaccType.Add(0);
                            usaccID.Add(0);
                            usaccName.Add("DefaultAdmin");
                            usaccPass.Add("D0000A");
                            // Set Config Status Flag
                            ConfigStatus = "NOTICE: Local Admin Config file loaded successfully.";

                            // Sanity check true
                            localSanityCheck = true;
                            break;
                        }
                        case 1:     // No Admin Account(s), "Make" default account
                        {
                            // Add default Admin values to object
                            usaccType.Add(0);
                            usaccID.Add(0);
                            usaccName.Add("DefaultAdmin");
                            usaccPass.Add("D0000A");
                            // Set 'no Admin Config' Flag
                            ConfigStatus = "ALERT: No Local Admin Config file found!";

                            // Sanity check true
                            localSanityCheck = true;
                            break;
                        }
                        case 2:     // Employee Manager Account(s) Present
                        {
                            // Read in from accEManager file
                            string[] linesb = File.ReadAllLines(folderfilepath);
                            string[] linesplitb;
                            int b = 0;
                            // Get values from EManager config, overwrite stored line with said value, counter +1
                            foreach(string line in linesb)
                            {
                                linesplitb = line.Split(":");
                                linesb[b] = linesplitb[1];
                                b++;
                            }
                            // Apply config values to object attributes, 'i' should always be a multiple of 4 if good config
                            for(int n = 1; n < b; n = n + 4)
                            {
                                usaccType.Add(Convert.ToInt32(linesb[n-1]));
                                usaccID.Add(Convert.ToInt32(linesb[n]));
                                usaccName.Add(linesb[n+1]);
                                usaccPass.Add(linesb[n+2]);
                            }           
                            // Set Config Status Flag
                            ConfigStatus = "NOTICE: Local Manager Config file loaded Successfully.";

                            // Sanity check true
                            localSanityCheck = true;     
                            break;
                        }
                        case 3:     // No Employee Manager Account(s)
                        {
                            // Set 'no Employee Manager Config' flag
                            ConfigStatus = "WARNING: No Local Manager Config file found!";

                            // Sanity check true
                            localSanityCheck = true;
                            break;
                        }
                        case 4:     // Employee Account(s) Present
                        {
                            // Read in from accEmployee file
                            string[] linesc = File.ReadAllLines(folderfilepath);
                            string[] linesplitc;
                            int c = 0;
                            // Get values from employee config, overwrite stored line with said value, counter +1
                            foreach(string line in linesc)
                            {
                                linesplitc = line.Split(":");
                                linesc[c] = linesplitc[1];
                                c++;
                            }
                            // Apply config values to object attributes, 'i' should always be a multiple of 4 if good config
                            for(int n = 1; n < c; n = n + 4)
                            {
                                usaccType.Add(Convert.ToInt32(linesc[n-1]));
                                usaccID.Add(Convert.ToInt32(linesc[n]));
                                usaccName.Add(linesc[n+1]);
                                usaccPass.Add(linesc[n+2]);
                            }
                            // Set Config Status Flag
                            ConfigStatus = "NOTICE: Local Employee Config file loaded Successfully.";

                            // Sanity check true
                            localSanityCheck = true;
                            break;
                        }
                        case 5:     // No Employee Account(s)
                        {
                            // Set 'no Employee config' flag
                            ConfigStatus = "WARNING: No Local Employee Config file found!";

                            // Sanity check true
                            localSanityCheck = true;
                            break;
                        }
                    }
                }
                catch(FormatException)
                {
                    badConfig = true;
                }
                catch(OverflowException)
                {
                    badConfig = true;
                }
            }
        }
    }

    // Methods
    public void checkUserexists(string userNametoCheck)
    {

    }


    // Logout
    public void usaccSignOut()
    {
        
    }

}