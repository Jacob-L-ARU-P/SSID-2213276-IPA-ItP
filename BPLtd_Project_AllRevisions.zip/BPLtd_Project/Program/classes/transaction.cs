// Transaction Class
// Represents the most basic and frequent event at the fuel station
// ----------------------------------------------------------------
class transaction
{
// Define Transaction Data
int TransactionID;
int LaneID;
int PumpID;
DateTime StartTime;
DateTime EndTime;
DateTime EllapsedTime;
Decimal FuelDispensed;
int FuelType;
Decimal FuelCost;

// Declare Constructor(s)
public transaction(){}
public transaction(int a)
{

}

//

}