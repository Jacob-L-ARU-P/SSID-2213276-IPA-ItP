// Lane Class
// Fuel Station Forecourt is made of Lanes, minimum of 1
// A Lane can have a variable number of pumps associated with it, min of 1

class lane
{
// lane class attributes
    int laneID;
    int numPumps;
    public List<pump> lanePumps = new List<pump>();


// Constructor(s)
    public lane(){}
    public lane(int initialiser)
    {

    }

// get method(s)


// Generate Pump(s)


}