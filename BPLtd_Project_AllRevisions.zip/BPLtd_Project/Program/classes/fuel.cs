// Fuel Class
// Defines a given fuel type offered by the Fuel Station
// Object(s) generated from config file at program start

class fuel
{
// fuel class attributes
    bool isBlank;
    string fuelType;
    int fuelTypeID;
    decimal fuelPricePerLitre;
    bool isOffered;

// Constructor(s)
    fuel(){}
    fuel(string filepath)
    {

    }

// get methods


// set methods (adjust price, admin/managers only)


}