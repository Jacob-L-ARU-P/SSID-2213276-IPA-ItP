﻿// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 0
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------

// Import non-standard Module(s)/Libraries (Date/Time, Randomness, etc)

// Load in Reference Object(s)
UserInterface thisInterface = new UserInterface();

// Declare Internal Variable(s)
thisInterface.userChoice = 0;

// Locate Path
string thisProgramPath = Directory.GetCurrentDirectory();
thisInterface.MyexpectedConfigsFolderpath = thisProgramPath + "\\configs";

// Program-Start Fluff
thisInterface.startscreen();

// Read In/Check Fuel Station Config File
Thread Worker = new Thread(new ThreadStart(thisInterface.sanitycheck));
Worker.Start();

// Wait for Worker thread to finish setting up object instances
Worker.Join();

// Main Program Loop
while(thisInterface.userChoice != 1)
{
    if(thisInterface.userChoice == 0) // Runs at program start, but is bypassed in later loops
    {
        Console.WriteLine("\t...Loading Complete!\n");
        Thread.Sleep(200);
        thisInterface.welcomescreen();
    }
    if(thisInterface.userChoice == 1) // Exit Check
    {
        break;
    }
    if(thisInterface.userChoice == 11) // 
    {
    thisInterface.userLoginSelectscreen();
    }
    switch(thisInterface.userChoice)
    {
        case 1:
        {
            break;
        }
        case 2 or 3:
        {
            thisInterface.userLoginScreen();
            break;
        }
        case 5:
        {
            thisInterface.adminLoginScreen();
            break;
        }
    }
    
}




// Program Exit Hold
Console.WriteLine("\n\n\tPress any key to exit.");
Console.ReadKey();