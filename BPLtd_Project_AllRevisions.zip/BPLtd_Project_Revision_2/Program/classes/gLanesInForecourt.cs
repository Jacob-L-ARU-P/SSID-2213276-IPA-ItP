// Lane Class
// The Fuel Station's Forecourt is composed of a number of Lanes
// Each Lane has an associated number of pumps, which can provide
// service to vehicles, generating transactions for the station
class lane
{
    // Lane Attributes

    // Lane Constructors

    // Lane Methods
    
}