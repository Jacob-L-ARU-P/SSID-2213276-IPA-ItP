// Fuel Station Class
// Digital "representation" of the Fuel Station, the 'Spine' of the business
class FuelStation
{
    // Station Attributes
    string[] FSConfigInOut;
    List<string> FSCIOValues = new List<string> ();
    string FuelStationName;
    int FuelStationID;
    int PumpsPerLane;
    int LanesInForecourt;
    int FuelsOffered;
    int VehicleRestrictions;
    int QueueSize;

    // Station Constructors
    public FuelStation(){}
    public FuelStation(string filepath)
    {
    // Read In Config File
    FSConfigInOut = File.ReadAllLines(filepath);
    string[] linesplit;
    int i = 0;
    // Trim readability whitespace from config file
    // And Get Config Values
    foreach(string line in FSConfigInOut)
    {
        FSConfigInOut[i] = line.Trim();
        linesplit = line.Split(":");
        FSCIOValues.Add(linesplit[1]);
        i++;
    }        
    // Assign Config Values to Station Attributes
    for(int n = 0; n < i; n++)
    {
        switch(n)
        {
            case 0:
            {
                this.FuelStationName = FSCIOValues[n];
                break;
            }
            case 1:
            {
                this.FuelStationID = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 2:
            {
                // Nothing to Assign Here
                break;
            }
            case 3:
            {
                this.PumpsPerLane = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 4:
            {
                this.LanesInForecourt = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 5:
            {
                this.FuelsOffered = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 6:
            {
                this.VehicleRestrictions = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
            case 7:
            {
                this.QueueSize = Convert.ToInt32(FSCIOValues[n]);
                break;
            }
        }
    }
    }

    // Station Dependants
    public userAccounts stationAccounts = new userAccounts();
    public List<fuels> stationFuels = new List<fuels>();
    public List<lane> stationLanes = new List<lane>();

    // 'Generate' Station Components, a.k.a. populate dependants


    // Station Configuration Methods
    public void generatecomponents(string MainProgramFilePath)
    {
        // User Accounts
        try
        {
            string[] checklines = File.ReadAllLines(MainProgramFilePath + "\\configs\\accounts.txt");
            int i = 0;
            foreach(string line in checklines)
            {
                i++;
            }
            int iC = i % 4;
            if(iC != 0)
            {
                throw new Exception("Bad Config");
            }
            else
            {
                stationAccounts = new userAccounts(MainProgramFilePath + "\\configs\\accounts.txt", false);
                stationAccounts.numAccounts = (i / 4) + 1;
            }
        }
        catch(FileNotFoundException)
        {
            stationAccounts = new userAccounts(MainProgramFilePath + "\\configs", true);
        }
        catch(Exception)
        {
            stationAccounts = new userAccounts(MainProgramFilePath + "\\configs\\accounts.txt", true);        
        }
        // Fuels
        switch(FuelsOffered)
        {
            case 0:
            {

                break;
            }
            case 1:
            {
                try
                {

                }
                catch(FileNotFoundException)
                {

                }
                break;
            }
            case 2:
            {
                try
                {

                }
                catch
                {
                    
                }
                break;
            }
            case 3:
            {
                try
                {

                }
                catch
                {

                }
                break;
            }
        }
    }
}