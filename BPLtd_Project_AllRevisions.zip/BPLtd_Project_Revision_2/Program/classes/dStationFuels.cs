// Fuel Class
// Each Instantiated object represent a given Fuel Type
// Offered by the Fuel Station
class fuels
{
    // Fuel Attributes
    
    // Fuel Constructors

    // Fuel Methods
}