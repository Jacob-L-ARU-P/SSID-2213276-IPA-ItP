// The Queue Monitor Class
// Handles Vehicle Generation and populating the Station's Queue
// Also Keeps track of total vehicles in and out, for those juicy juicy efficacy analytics
class queueMonitor
{
    // Queue Monitor Attributes

    // Queue Monitor Constructors

    // Queue Monitor Methods

}