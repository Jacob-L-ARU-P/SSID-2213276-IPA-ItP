// Transaction Class
// The Fuel Station's proverbial 'Bread & Butter'
// Every time a Pump is occupied, and thus a vehicle serviced,
// an associated transaction is generated
class transaction
{
    // Transaction Attributes
    int transactionID;
    int laneID;
    int pumpID;
    int fuelType;
    decimal fuelDispensed;
    decimal fuelCost;
    DateTime startTime;
    DateTime endTime;
    TimeSpan ellapsedTime;
    // Transaction Constructors
    public transaction(){}
    public transaction(int number)
    {

    }
    // Transaction Method(s)

}