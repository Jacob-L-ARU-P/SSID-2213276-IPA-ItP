// Pump Class
// Each Pump has a position in its Lane, along with an occupancy status
class pump
{
    // Pump Attributes
    int laneID;
    int pumpID;
    bool isOccupied;
    List<transaction> pumpTransactions = new List<transaction>();
    // Pump Constructors
    public pump(){}
    public pump(int lanePos)
    {

    }
    // Pump Methods

}