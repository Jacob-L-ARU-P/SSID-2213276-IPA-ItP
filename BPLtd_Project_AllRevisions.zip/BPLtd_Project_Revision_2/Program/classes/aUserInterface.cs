// Program Backbone
class UserInterface
{
    // Main Filepath to top-level folder, set by program at run-time
    public string MainProgramFilePath;
    public string iUtC = "", iPtC = "";
    // Instantiate blank Fuel Station, which will Instantiate blanks of it's dependants
    public FuelStation BP_FuelStation = new FuelStation();
    // Usefull Variable(s)
    public int userChoice;

    // User Interface Methods
    // Startscreen: Generates the initial Console Window
    public void startscreen()
    {
        Console.Clear();
        Console.Write("\n\t...Loading Please Wait...");
    }
    // Welcome Splash Screen
    public void welcomescreen()
    {
        // local logic bool(s)
        bool validKeyPress = false;
        // Make user press enter key to go to login
        while(validKeyPress != true)
        {
            Console.Clear();
            Console.WriteLine("\n\tWelcome to the Broken Petrol Ltd");
            Console.WriteLine("\tFuel Station Managemant Aid Program");
            Console.WriteLine("\n\tPress Enter to Continue to login");
            Console.WriteLine("\n\tOr Escape (esc) to exit.");
            switch(Console.ReadKey(true).Key)
            {
                case ConsoleKey.Escape:
                {
                    userChoice = 1;
                    validKeyPress = true;
                    break;
                }
                case ConsoleKey.Enter:
                {
                    userChoice = 11;
                    validKeyPress = true;
                    break;
                }
                default:
                {
                    break;
                }
            }
        }
    }
    // User Login Screen
    public void loginScreen()
    {
        // local logic variable(s)
        bool validKeyPress = false;
        int leftU, topU, leftP, topP, leftL, leftC, topC;
        // 
        Console.Clear();
        Console.WriteLine("\n\t----- Broken Petrol Ltd: Fuel Attendant Login -----");
        Console.WriteLine("\t-----  Please enter your Username & Password  -----");
        Console.WriteLine("\t-----  Press Tab to switch your entry field,  -----");
        Console.WriteLine("\t-----  Press Enter to submit login details or -----");
        Console.WriteLine("\t-----  Press Escape (Esc) to Exit Program.    -----");
        Console.Write("\tUsername: ");
        (leftU, topU) = Console.GetCursorPosition();
        Console.Write("\n\tPassword: ");
        (leftP, topP) = Console.GetCursorPosition();
        Console.SetCursorPosition(leftU, topU);
        leftL = leftP;
        while(validKeyPress != true)
        {
            ConsoleKeyInfo uki = Console.ReadKey(true);
            switch(uki.Key)
            {
                case(ConsoleKey.Tab):
                {
                    (leftC, topC) = Console.GetCursorPosition();
                    switch(topC)
                    {
                        case 6:
                        {
                            Console.SetCursorPosition(leftL, topP);
                            leftL = leftC;
                            break;
                        }
                        case 7:
                        {
                            Console.SetCursorPosition(leftL, topU);
                            leftL = leftC;
                            break;
                        }
                    }
                    break;
                }
                case (ConsoleKey.Escape):
                {
                    validKeyPress = true;
                    userChoice = 1;
                    break;
                }
                case (ConsoleKey.Enter):
                {
                    validKeyPress = true;
                    userChoice = 2;
                    break;
                }
                case (ConsoleKey.Backspace):
                {
                    (leftC, topC) = Console.GetCursorPosition();
                    if(leftC > 18)
                    {
                    Console.SetCursorPosition(leftC - 1, topC);
                    Console.Write(" ");
                    Console.SetCursorPosition(leftC - 1, topC);
                    if(topC == topU)
                    {
                        int a = iUtC.Length;
                        iUtC = iUtC.Remove(a-1); // string indexing starts at zero
                    }
                    else
                    {
                        int a = iPtC.Length;
                        iPtC = iPtC.Remove(a-1);
                    }
                    }
                    break;
                }
                default:
                {
                    (leftC, topC) = Console.GetCursorPosition();
                    if(topC == topU)
                    {
                        iUtC = iUtC + uki.KeyChar.ToString(); // KeyChar to account for ConsoleModifiers in input/output
                        Console.Write(uki.KeyChar);
                    }
                    else
                    {
                        iPtC = iPtC + uki.KeyChar.ToString();
                        Console.Write("*");
                    }
                    break;
                }
            }
        }
    }
    // Employee Screen

    // Manager Screen

    // Admin Screen

    // Shift Screen(s)
    public void preShift()
    {
        Console.Clear();
        Console.WriteLine("\n\tPress 1 for Manual Allocation\n\tPress 2 for Auto Assignment\n");

    }

    public void theShift()
    {

    }

    // Sanity Check ----- Checks/Validates/Tests Fuel Station Config File before generating the Program's Fuel Station Object
    public void sanitycheck()
    {
        // check file exists
        try
        {
        File.ReadAllLines(MainProgramFilePath + "\\configs\\station.txt");
        Console.Write("05%...\n\t");
        // Read in all lines of config
        string[] lines = File.ReadAllLines(MainProgramFilePath + "\\configs\\station.txt");
        // intermediate array for splitting up each line
        string[] lineSplit;
        // Final array of split config data, col 0 = config name, col 1 = config value
        string[,] splitLineStack = new string[lines.Length,2];
        // indexing counter
        int i = 0;
        // Trim readability whitespace from config file
        foreach(string line in lines)
        {
            lines[i] = line.Trim();
            i++;
        }    
        Console.Write("...10%...");
        // Split each line of config file and save to new array
        i = 0;
        foreach(string line in lines)
        {
            lineSplit = line.Split(":");
            splitLineStack[i,0] = lineSplit[0];
            splitLineStack[i,1] = lineSplit[1];
            i++;
        }
        Console.Write("15%...");
        // Check config file is "good"
        for(int n = 0; n < i; n++)
        {
        // Check all expected config fields are present
            switch(splitLineStack[n,0])
            {
                case("FuelStationName"):
                {
                    break;
                }
                case("FuelStationID"):
                {
                    break;
                }
                case("StationData"):
                {
                    break;
                }
                case("PumpsPerLane"):
                {
                    break;
                }
                case("LanesInForecourt"):
                {
                    break;
                }
                case("FuelsOffered"):
                {
                    break;
                }
                case("VehicleRestrictions"):
                {
                    break;
                }
                case("QueueSize"):
                {
                    break;
                }
            // In the event a line from the config does NOT match any
            // of the expected fields, throw an error
                default:
                {
                    throw new Exception("Missing Expected Config Field");
                }
            }
            // Check all expected fields have an appropriate non-null value
            // I.e. Station name is a string with any amount of characters in it,
            // Station ID and such are positive integers, etc. Otherwise, throw error
            switch(splitLineStack[n,1])
            {
                case(null):
                {
                    throw new Exception("Missing Valid Config Field Value");
                }
                default:
                {
                    switch(n)
                    {
                        case 0:
                            // Check Station Name is not empty string
                        {
                            string a = splitLineStack[0,1];
                            bool b = string.IsNullOrEmpty(a);
                            bool c = string.IsNullOrWhiteSpace(a);
                            if(b == true)
                            {
                                throw new Exception("Missing Valid Station Name");
                            }
                            else if(c == true)
                            {
                                throw new Exception("Missing Valid Station Name,\n\tcannot be whitespace, e.g. '    '.");
                            }
                            else
                            {
                                break;
                            }
                        }
                        case 1:
                            // Check Station has a valid, non-zero, non-negative ID number
                        {
                            int a = Convert.ToInt32(splitLineStack[1,1]);
                            if(a > 0)
                            {
                                break;
                            }
                            else
                            {
                                throw new Exception("Missing Valid Config Field Value");
                            }
                        }
                        case 2:
                            // Check's StationData line hasn't been messed with
                        {
                            if(splitLineStack[2,1] == "#")
                            {
                                break;
                            }
                            else
                            {
                                throw new Exception("Missing StationData Config Field Value, should be '#'.");
                            }
                        }
                        case 3:
                            // Checks Pumps Per Lane is a non-zero, non-negative, less than 10 integer
                        {
                            int a = Convert.ToInt32(splitLineStack[3,1]);
                            switch(a)
                            {
                                case <=0:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                                }
                                case >10:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tshould be 10 or less");
                                }
                                default:
                                {
                                    break;
                                }
                            }
                            break;
                        }
                        case 4:
                            // Checks Lanes in Forecourt is a non-zero, non-negative, less than 10 integer
                        {
                            int a = Convert.ToInt32(splitLineStack[4,1]);
                            switch(a)
                            {
                                case <=0:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                                }
                                case >10:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tshould be 10 or less");
                                }
                                default:
                                {
                                    break;
                                }
                            }
                            break;
                        }
                        case 5:
                            // Checks Fuels Offered is a non-negative, less than 10 integer
                        {
                            int a = Convert.ToInt32(splitLineStack[5,1]);
                            switch(a)
                            {
                                case <0:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                                }
                                case >10:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tshould be 10 or less.\n\tMore than 11 types of fuel is outside the scope of this project");
                                }
                                default:
                                {
                                    break;
                                }
                            }
                            break;
                        }
                        case 6:
                            // Checks Vehicle Restrictions is a non-negative, less than 5 integer
                        {
                            int a = Convert.ToInt32(splitLineStack[6,1]);
                            switch(a)
                            {
                                case <=0:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                                }
                                case >5:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tshould be 5 or less.\n\tHigher Values outside project scope.");
                                }
                                default:
                                {
                                    break;
                                }
                            }
                            break;
                        }
                        case 7:
                            // Checks Forecourt Queue is a non-zero, non-negative, less than 10 integer
                        {
                            int a = Convert.ToInt32(splitLineStack[3,1]);
                            switch(a)
                            {
                                case <=0:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tcannot be less than or equal to Zero (0)");
                                }
                                case >10:
                                {
                                    throw new Exception("Missing Valid Config Field Value,\n\tshould be 10 or less");
                                }
                                default:
                                {
                                    break;
                                }
                            }
                            break;
                        }
                        default:
                            // In the Event More FuelStation Config lines are added, without an associated valid value check
                        {
                            throw new Exception("Missing Expected Config Field Value Check");
                        }
                    }
                    break;
                }
            }
        }
        Console.Write("25%...");
        // Config Exists and is not "Corrupt"
        // Doesn't mean any of the values won't break the program later though
        // Pass config filepath to constructor
        // Thus Creating the programs Fuel Station Object, local instance called 'BP_FuelStation'
        BP_FuelStation = new FuelStation(MainProgramFilePath + "\\configs\\station.txt");
        Console.Write("...30%...");
        BP_FuelStation.generatecomponents(MainProgramFilePath);
        Console.Write("90%...\n");
        }
        // Error Catching
        catch(FileNotFoundException)
        {
            Console.Clear();
            Console.WriteLine("\n\tWARNING: Fuel Station Config Not Found!");
            Thread.Sleep(250);
            userChoice = 1;
        }
        catch(System.IO.IOException e)
        {
            Console.Clear();
            Console.WriteLine("\n\tWARNING: Unexpected Error!");
            Console.WriteLine("\t" + e.Message);
            Thread.Sleep(250);
            userChoice = 1;
        }
        catch(FormatException)
        {        
            Console.Clear();
            Console.WriteLine("\n\tWARNING: Bad Config/Config Corrupt!");
            Console.WriteLine("\tAttempted to Convert letter(s) to numbers,\nfailed.");
            Thread.Sleep(250);
            userChoice = 1;
        }
        catch(OverflowException)
        {
            Console.Clear();
            Console.WriteLine("\n\tWARNING: Bad Config/Config Corrupt!");
            Console.WriteLine("\tValue in Config too large, expected 32-bit integer.");
            Thread.Sleep(250);
            userChoice = 1;       
        }
        // Custom Exception Catch
        catch(Exception e)
        {
            Console.Clear();
            Console.WriteLine("\n\tWARNING: Bad Config/Config Corrupt!");
            Console.WriteLine("\t" + e.Message);
            Thread.Sleep(250);
            userChoice = 1;
        }
    }
}