// Consolidated User Account Class
class userAccounts
{
    // User Account Attributes
    List<int> usaccType = new List<int>();
    List<int> usaccID = new List<int>();
    List<string> usaccName = new List<string>();
    List<string> usaccPass = new List<string>();
    public int numAccounts;
    public string ConfigStatus;
    // User Account Constructors
    public userAccounts(){}
    public userAccounts(string filepath, bool badconfig)
    {
        bool localSanityCheck = false;
        while(localSanityCheck != true)
        {
            if(badconfig == true)
            {
                // Add default Admin values to object
                usaccType.Add(0);
                usaccID.Add(0);
                usaccName.Add("DefaultAdmin");
                usaccPass.Add("D0000A");
                // Set Config Status Flag
                ConfigStatus = "ERROR: Bad Config, check file is present:\n\t" + filepath;

                // Sanity check true
                localSanityCheck = true;
                break;
            }
            else
            {
                try
                {
                    // Read in from Accounts file
                    string[] linesa = File.ReadAllLines(filepath);
                    string[] linesplita;
                    int a = 0;
                    // Add default Admin values to object
                    usaccType.Add(0);
                    usaccID.Add(0);
                    usaccName.Add("DefaultAdmin");
                    usaccPass.Add("D0000A");
                    // Get values from Accounts config, overwrite stored line with said value, counter +1
                    foreach(string line in linesa)
                    {
                        linesplita = line.Split(":");
                        linesa[a] = linesplita[1];
                        a++;
                    }                          
                    // Apply config values to object attributes, 'i' should always be a multiple of 4 if good config
                    for(int n = 1; n < a; n = n + 4)
                    {
                        usaccType.Add(Convert.ToInt32(linesa[n-1]));
                        usaccID.Add(Convert.ToInt32(linesa[n]));
                        usaccName.Add(linesa[n+1]);
                        usaccPass.Add(linesa[n+2]);
                    }
                    // Set Config Status Flag
                    ConfigStatus = "NOTICE: Accounts config loaded successfully";

                    // Sanity check true
                    localSanityCheck = true;
                    break;
                }
                catch(FormatException)
                {
                    badconfig = true;
                }
                catch(OverflowException)
                {
                    badconfig = true;
                }                
            }
        }
    }

    // User Account Methods
    public string checkUserName(int i)
    {
        return usaccName[i];
    }
    public string checkUserPass(int i)
    {
        return usaccPass[i];
    }
    public int getAccountType(int i)
    {
        return usaccType[i];
    }
}