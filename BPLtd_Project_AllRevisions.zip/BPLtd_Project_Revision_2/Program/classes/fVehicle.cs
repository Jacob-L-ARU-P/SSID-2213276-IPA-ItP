// Vehicle Class
class vehicle
{
    // 
}