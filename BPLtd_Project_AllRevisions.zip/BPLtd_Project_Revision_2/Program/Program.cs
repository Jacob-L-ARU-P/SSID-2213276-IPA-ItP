﻿// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 2.1, Revision 3
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// Instantiate User Interface, the Programs 'Spine'
UserInterface thisInterface = new UserInterface();
// Figure out where the .exe file is running from
string thisProgramPath = Directory.GetCurrentDirectory();
thisInterface.MainProgramFilePath = thisProgramPath;
// Top-Level internal variable(s)
thisInterface.userChoice = 0;
// Program-Start Fluff
thisInterface.startscreen();
// Read In/Check Fuel Station Config File
// If Good, Build Station and it's dependents
thisInterface.sanitycheck();
// Main Program Loop
while(thisInterface.userChoice != 1)
{
    if(thisInterface.userChoice == 0) // Runs at program start, but is bypassed in later loops
    {
        Console.WriteLine("\t...Loading Complete!\n");
        Thread.Sleep(200);
        thisInterface.welcomescreen();
    }
    if(thisInterface.userChoice == 1) // Exit Check
    {
        break;
    }
    if(thisInterface.userChoice == 11) // 
    {
        thisInterface.loginScreen();
    }
    if(thisInterface.userChoice == 2) // Check login details, display appropriate user screen
    {
        bool AccCheckdone = false;
        while(AccCheckdone != true)
        {
            for(int i = 0; i < thisInterface.BP_FuelStation.stationAccounts.numAccounts; i++)
            {
                if((thisInterface.iUtC == thisInterface.BP_FuelStation.stationAccounts.checkUserName(i)) && (thisInterface.iPtC == thisInterface.BP_FuelStation.stationAccounts.checkUserPass(i)))
                {
                    Console.WriteLine("\n\tVaild Login Credentials");
                    switch(thisInterface.BP_FuelStation.stationAccounts.getAccountType(i))
                    {
                        case 0:
                        {
                            
                            break;
                        }
                        case 1:
                        {
                            break;
                        }
                        case 2:
                        {
                            break;
                        }
                    }
                    Thread.Sleep(250);

                }
            }
        }
    }
}

// Program Exit Hold, To be disabled for final release.
Console.WriteLine("\n\n\tPress any key to exit.");
Console.ReadKey();