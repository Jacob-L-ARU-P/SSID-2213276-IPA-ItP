// ----------------------------------------------------------
// 'Broken Petrol Ltd' Petrol Station Management Application
//  Version: 0
// ----------------------------------------------------------
//  Code by Jacob Lummis
//  ARU-P SID: 2213276
// ----------------------------------------------------------
// Vehicle Class:
class vehicle
{
    // Vehicle Attribute:
    // At this level, it consists of an ID number for counting purposes.
    int VehicleNumber;

    // Vehicle Constructors:
    // Blank Constructor for program initialisation
    public vehicle(){}
    // Constructor used when generating vehicle object instances.
    public vehicle(int vnum)
    {
        VehicleNumber = vnum;
    }
}
// Full Program: 444 Lines of Code, including Comments and Whitespace.