class fuelStation
{
    bool[,] Forecourt = new bool[3,3];
    public string[] pump = new string[10]{"OPEN","OPEN","OPEN","OPEN","OPEN","OPEN","OPEN","OPEN","OPEN",""};



    public fuelStation()
    {
        for(int n = 0; n < 3; n++)
        {
            for(int i = 0; i < 3; i++)
            {
                Forecourt[n,i] = false;
            }
        }
    }

    public void pumpAssigned(int pumpID)
    {
        switch(pumpID)
        {
            case 1:
            {
                Forecourt[0,0] = true;
                pump[0] = "BUSY";
                break;
            }
            case 2:
            {
                Forecourt[0,1] = true;
                pump[1] = "BUSY";
                break;
            }
            case 3:
            {
                Forecourt[0,2] = true;
                pump[2] = "BUSY";
                break;
            }
            case 4:
            {
                Forecourt[1,0] = true;
                pump[3] = "BUSY";
                break;
            }
            case 5:
            {
                Forecourt[1,1] = true;
                pump[4] = "BUSY";
                break;
            }
            case 6:
            {
                Forecourt[1,2] = true;
                pump[5] = "BUSY";
                break;
            }
            case 7:
            {
                Forecourt[2,0] = true;
                pump[6] = "BUSY";
                break;
            }
            case 8:
            {
                Forecourt[2,1] = true;
                pump[7] = "BUSY";
                break;
            }
            case 9:
            {
                Forecourt[2,2] = true;
                pump[8] = "BUSY";
                break;
            }
        }
    }

    public void pumpDeassigned(int pumpID)
    {
        switch(pumpID)
        {
            case 1:
            {
                Forecourt[0,0] = false;
                pump[0] = "OPEN";
                break;
            }
            case 2:
            {
                Forecourt[0,1] = false;
                pump[1] = "OPEN";
                break;
            }
            case 3:
            {
                Forecourt[0,2] = false;
                pump[2] = "OPEN";
                break;
            }
            case 4:
            {
                Forecourt[1,0] = false;
                pump[3] = "OPEN";
                break;
            }
            case 5:
            {
                Forecourt[1,1] = false;
                pump[4] = "OPEN";
                break;
            }
            case 6:
            {
                Forecourt[1,2] = false;
                pump[5] = "OPEN";
                break;
            }
            case 7:
            {
                Forecourt[2,0] = false;
                pump[6] = "OPEN";
                break;
            }
            case 8:
            {
                Forecourt[2,1] = false;
                pump[7] = "OPEN";
                break;
            }
            case 9:
            {
                Forecourt[2,2] = false;
                pump[8] = "OPEN";
                break;
            }
            default:
            {
                break;
            }
        }
    }

    public bool[,] getForecourtState()
    {
        return Forecourt;
    }

}