﻿//

userInterface thisInterface = new userInterface();
thisInterface.userChoice = 0;
Thread observer = new Thread(thisInterface.VehicleCounter);
Thread checker = new Thread(thisInterface.vehicleRemover);
Thread refresher = new Thread(thisInterface.screenRefresher);
observer.Start();
checker.Start();

while(thisInterface.userChoice != 1)
{
    if(thisInterface.userChoice == 0)
    {
        thisInterface.welcomeScreen();
    }
    if(thisInterface.userChoice == 2)
    {
        thisInterface.homeScreen();
    }
    if(thisInterface.userChoice == 3)
    {
        refresher.Start();
        thisInterface.shiftScreen();
    }
    // if(thisInterface.userChoice == 4)
    // {

    // }
}

Console.WriteLine("\n\tPress any key to exit.");
Console.ReadKey();